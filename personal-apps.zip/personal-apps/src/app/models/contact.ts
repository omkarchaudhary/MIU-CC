export interface Contact{
    email: string | undefined;
    name: string | undefined;
    subject: string | undefined;
    message: string | undefined;
}