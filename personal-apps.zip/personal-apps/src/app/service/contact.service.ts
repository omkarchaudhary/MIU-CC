import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Contact } from '../models/contact';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactService {
  baseUrl: string = "https://42o2tq3pgi.execute-api.us-east-1.amazonaws.com/dev/contact";

  constructor(private httpClient : HttpClient) { }

  createContact(data : Contact) : Observable<Contact>{
    return this.httpClient.post<Contact>(this.baseUrl, data);
  }
}
