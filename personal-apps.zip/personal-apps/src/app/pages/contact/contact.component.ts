import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { ContactService } from '../../service/contact.service';
import { response } from 'express';
import { error } from 'console';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-contact',
  standalone: true,
  imports: [ReactiveFormsModule, CommonModule],
  templateUrl: './contact.component.html',
  styleUrl: './contact.component.css'
})
export class ContactComponent {
  contactForm!: FormGroup;
  showFailure : boolean = false;
  showSuccess : boolean = false;
  errorMessage: String ="";
  successMessage: String="";
  isSubmitted: boolean=false;
  constructor(private formBuilder: FormBuilder, private contactService: ContactService){
    this.createContactForm();
  }

  get f(){
    return this.contactForm.controls;
  }

  createContactForm(){
    this.contactForm = this.formBuilder.group({
      email:['', [Validators.email, Validators.required]],
      name:['', [Validators.required]],
      subject:['', [Validators.required]],
      message:['', [Validators.required]]
    })
  }

  onSubmit(){
    this.isSubmitted = true;
    if(this.contactForm.valid){
      const data = {
        name: this.contactForm.value.name,
        email: this.contactForm.value.email,
        subject: this.contactForm.value.subject,
        message: this.contactForm.value.message
      };
      console.log("The form data "+ data);
      this.contactService.createContact(data).subscribe(
        response => {
          this.showSuccess = true;
          this.successMessage = "Message send successfully. Will get you back soon. Thank you";
          this.errorMessage = "";
          console.log("The success response "+response);
          this.contactForm.reset();
        },
        (error :any) => {
          this.showFailure = true;
          this.errorMessage = "Message send failed. please try again";
          this.successMessage = "";
          console.log("The error response "+error)
        }
      );
      this.isSubmitted = false;
    }
    
  }

}
